export default {
    LOGIN: 'user_login', //登陆
    /*分类管理*/
    classifyList: 'video_list_info', //默认进入分类管理页面获取
    classvideoList: 'type_list', //获取默认分类
    upVideoName: 'type_list', //筛选获取
    isShowVideo: 'is_show_update', //控制上下架
    classifyNew: 'add_class_info', //新建分类
    viedeoNew: 'add_tv_info',
    delectViedeo: 'video_delete_info', // 删除视频
    modifyViedeo: 'video_update_info', // 修改视频
    sortInfo: 'video_sort_info', // 排序查询
    SEARCHVIDEO: 'video_search_info',
    getosstoken: 'get_oss_token', // 获取视频token
    getFileTime: 'get_file_info' //获取视频信息
}